#pragma once
#include "A1.h"
class C1 : public A1
{
public:
void f();
void accepte(VisiteurA1B1C1 * v);
};

