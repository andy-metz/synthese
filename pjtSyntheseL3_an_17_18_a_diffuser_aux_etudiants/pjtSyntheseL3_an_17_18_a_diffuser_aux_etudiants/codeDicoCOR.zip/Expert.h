//class S;
//class D;
//
//class Expert
//{
//**
//@param d : donn�e du probl�me � r�soudre
//@return la solution ou NULL en cas d�chec
//*/
//virtual  S * resoudre (const D & d) const = 0;
//};