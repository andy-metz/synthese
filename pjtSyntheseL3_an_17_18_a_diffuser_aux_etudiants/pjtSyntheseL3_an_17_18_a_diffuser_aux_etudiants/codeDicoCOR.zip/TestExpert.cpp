//#include "Expert.h"
//#include "ExpertCOR.h"
//
//int main1()
//{
//ExpertCor * expert ;
//
//expert = new ExpertCOR3(NULL);
//expert = new ExpertCOR2(expert);
//expert = new ExpertCOR1(expert);
//
//D d(�) ;
//
//S * s = expert->r�soudre(d); 	// ignore volontairement comment expert // est mis en oeuvre
//return 0;
//}
