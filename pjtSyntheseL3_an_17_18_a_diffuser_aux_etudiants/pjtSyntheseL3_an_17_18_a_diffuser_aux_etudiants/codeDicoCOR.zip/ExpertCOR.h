//#pragma once
//
//#include <stdlib.h>
//#include "Expert.h"
//
//class ExpertCOR : public Expert
//{
//ExpertCOR * suivant;  // expert suivant dans la cha�ne
//
//protected:	
//ExpertCOR(ExpertCOR * expertSuivant);
//
//public:
//S * resoudre (const D & d) const;
//
//protected:
//virtual S * resoudre1(const D & d) const = 0;
//};
