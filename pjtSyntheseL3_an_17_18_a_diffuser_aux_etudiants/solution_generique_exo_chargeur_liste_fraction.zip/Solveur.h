#pragma once

/**
classe de base de toutes les classes sachant resoudre un pb ayant d pour donn�e et un S comme solution
*/
template <class S, class D>
class Solveur
{
public:

/**
r�sout le probl�me d et trouve une solution s instance de S

Convention : en cas d'�chec  retourne NULL

*/
virtual S * resoudre(const D & d) const = 0;
};



