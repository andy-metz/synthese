#pragma once
#include <string>
#include "SolveurCOR.h"
#include "Fraction.h"

/**
sait reconna�tre le format :  nombre entier  %

*/
class ParseurFractionCORPourcent : public SolveurCOR<Fraction,string>
{
public:
ParseurFractionCORPourcent(SolveurCOR<Fraction,string> * suivant);


/**
reconna�t le format : nombre entier  %
Convention : en cas d'�chec (format non reconnu) retourne NULL
transforme le texte en Fraction
*/
Fraction * resoudre1(const string & d) const;
};