#pragma once
#include <string>
#include "SolveurCOR.h"
#include "Fraction.h"

class ParseurFractionCORSlash : public SolveurCOR<Fraction, string>
{
public:
/**
encha�ne ce maillon � suivant en le pla�ant en t�te
*/
ParseurFractionCORSlash(SolveurCOR<Fraction, string> * suivant);

/**
savoir-faire d'un expert en particulier. D�fini par les classes d�riv�es de SolveurCOR
Convention : en cas d'�chec  retourne NULL
*/
virtual Fraction * resoudre1(const string & d) const;				// virtual S * resoudre1(const D & d) const = 0;

};

