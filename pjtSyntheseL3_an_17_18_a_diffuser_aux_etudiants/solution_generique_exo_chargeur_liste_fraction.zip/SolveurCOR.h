#pragma once
#include "Solveur.h"

/**
solveur utilisant une cha�ne de responsabilit�

*/
template <class S, class D>
class SolveurCOR : public Solveur<S,D>
{
SolveurCOR<S,D> * suivant;	// solveur suivant dans la cha�ne
public:

/**
encha�ne ce maillon � suivant en le pla�ant en t�te
*/
SolveurCOR(SolveurCOR<S,D> * suivant);

/**
r�sout le probl�me d et trouve une solution s instance de S
algo utilis� : parcourt la cha�ne

Convention : en cas d'�chec  retourne NULL

*/
S * resoudre(const D & d) const;

/**
savoir-faire d'un expert en particulier. D�fini par les classes d�riv�es de SolveurCOR
Convention : en cas d'�chec  retourne NULL
*/
virtual S * resoudre1(const D & d) const = 0;
};

/**
encha�ne ce maillon � suivant en le pla�ant en t�te
*/
template <class S, class D>
SolveurCOR<S,D>::SolveurCOR(SolveurCOR<S,D> * suivant) : suivant(suivant) {}


/**
r�sout le pb d en parcourant la cha�ne

Convention : en cas d'�chec  retourne NULL

algo utilis� : parcourt la cha�ne

*/
template <class S, class D>
S * SolveurCOR<S,D>::resoudre(const D & d) const
{
S * resultat;

resultat = this->resoudre1(d);		// ce maillon tente de r�soudre le pb

if (resultat)			// ce maillon a reconnu le probl�me et a obtenu une solution
	return resultat;
else					// �chec de ce maillon
	if (this->suivant)		// ce maillon n'est pas le dernier de la cha�ne
		return this->suivant->resoudre(d);			// on confie le probl�me au maillon suivant
	else											// ce maillon est le dernier donc �chc de la cha�ne
		return NULL;
}


